import { Card, CardContent } from "../components/ui/card";
import { testimonials } from "../utils/constants";
import { Star, Quote } from "lucide-react";

export function Testimonials() {
  return (
    <section className="py-32 px-6 bg-slate-950">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Quote className="h-12 w-12 text-indigo-500/30 mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-4 tracking-tight">
            Client Stories
          </h2>
          <p className="text-slate-400 text-lg">
            Don't just take our word for it
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <Card 
              key={testimonial.id}
              className="bg-slate-900/50 border-slate-800 hover:border-indigo-500/30 transition-all duration-300"
            >
              <CardContent className="p-8">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className="h-4 w-4 fill-indigo-500 text-indigo-500" 
                    />
                  ))}
                </div>
                <blockquote className="text-slate-300 text-lg leading-relaxed mb-8 font-light">
                  "{testimonial.quote}"
                </blockquote>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-slate-400 font-bold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-50">{testimonial.name}</p>
                    <p className="text-sm text-slate-500">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}