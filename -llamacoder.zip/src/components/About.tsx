import { Check, Shield, User } from "lucide-react";
import { brand } from "../utils/constants";

export function About() {
  const stats = [
    { value: "10+", label: "Years Experience" },
    { value: "5k+", label: "Happy Clients" },
    { value: "100%", label: "Satisfaction" }
  ];

  return (
    <section className="py-32 px-6 bg-slate-900">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image/Visual Area */}
          <div className="relative">
            <div className="aspect-[4/5] bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 relative">
              {/* Abstract Modern Pattern */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,#1e1b4b,transparent_50%)]" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 mx-auto mb-6 bg-indigo-500/10 rounded-2xl flex items-center justify-center border border-indigo-500/20">
                    <User className="h-12 w-12 text-indigo-400" />
                  </div>
                  <h4 className="text-slate-300 font-medium text-lg">The Visionary</h4>
                </div>
              </div>
            </div>
            {/* Floating Stats Card */}
            <div className="absolute -bottom-8 -right-8 bg-slate-950 border border-slate-800 p-6 rounded-2xl shadow-2xl hidden md:block">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center">
                  <Check className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Certified</p>
                  <p className="text-slate-50 font-bold">Excellence</p>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div>
            <div className="inline-block px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-sm font-medium mb-6">
              OUR FOUNDER
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
              Meet {brand.founder}
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed mb-6">
              With over a decade of experience in luxury skincare and therapy, 
              Amaka Oyoria founded <span className="text-indigo-400 font-semibold">Bud Again Beauty Spa</span> with a singular mission: 
              to help women and men rediscover their inner radiance.
            </p>
            <p className="text-slate-400 text-lg leading-relaxed mb-8">
              "Beauty isn't just about how you look—it's about how you feel. 
              At Bud Again, we create an environment where you can bloom again, 
                  leaving behind the stress of the world."
            </p>

            <div className="grid grid-cols-3 gap-8 mb-10">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <p className="text-3xl md:text-4xl font-bold text-slate-50 mb-1">
                    {stat.value}
                  </p>
                  <p className="text-slate-500 text-sm uppercase tracking-wider">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              {["Licensed Expert", "Organic Products", "Private Suites"].map((item) => (
                <div key={item} className="flex items-center gap-2 text-slate-300">
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}