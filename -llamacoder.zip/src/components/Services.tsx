import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { services } from "../utils/constants";
import { Clock, ArrowRight } from "lucide-react";

export function Services() {
  const categories = Array.from(new Set(services.map(s => s.category)));

  return (
    <section className="py-32 px-6 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16 gap-6">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-4 tracking-tight">
              Curated Therapies
            </h2>
            <p className="text-slate-400 text-lg max-w-xl">
              Precision treatments backed by modern wellness science
            </p>
          </div>
          <div className="hidden md:block">
            <div className="h-px w-32 bg-gradient-to-r from-indigo-500 to-transparent" />
          </div>
        </div>

        {categories.map((category) => (
          <div key={category} className="mb-20 last:mb-0">
            <div className="flex items-center gap-4 mb-8">
              <div className="h-8 w-1 bg-indigo-500 rounded-full" />
              <h3 className="text-2xl font-semibold text-slate-200 tracking-wide">
                {category.toUpperCase()}
              </h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services
                .filter((service) => service.category === category)
                .map((service) => (
                  <Card 
                    key={service.id} 
                    className="bg-slate-900/50 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 transition-all duration-300 group backdrop-blur-sm"
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start mb-2">
                        <CardTitle className="text-slate-50 group-hover:text-indigo-400 transition-colors text-xl">
                          {service.name}
                        </CardTitle>
                        <ArrowRight className="h-5 w-5 text-slate-600 group-hover:text-indigo-400 transition-colors opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0" />
                      </div>
                      <CardDescription className="text-slate-400 leading-relaxed">
                        {service.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                        <div className="flex items-center gap-2 text-sm text-slate-500">
                          <Clock className="h-4 w-4" />
                          <span>{service.duration}</span>
                        </div>
                        <span className="text-lg font-bold text-slate-50">
                          {service.price}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}