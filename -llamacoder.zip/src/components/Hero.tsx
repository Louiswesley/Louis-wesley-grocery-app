import { Button } from "../components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import { brand } from "../utils/constants";

export function Hero() {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById("booking");
    bookingSection?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-slate-950 overflow-hidden">
      {/* Ambient Glow Effect */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[128px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-[128px]" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 border border-slate-800 mb-8">
          <Sparkles className="h-4 w-4 text-indigo-400" />
          <span className="text-sm text-slate-400 font-medium tracking-wide">
            FOUNDED BY {brand.founder.toUpperCase()}
          </span>
        </div>

        <h1 className="text-6xl md:text-8xl font-bold text-slate-50 mb-6 tracking-tight leading-[0.9]">
          Bud Again
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">
            Beauty Spa
          </span>
        </h1>

        <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
          {brand.tagline}. Experience personalized luxury treatments designed 
          to restore your natural glow.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={scrollToBooking}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-6 text-lg rounded-full shadow-lg shadow-indigo-500/25 transition-all duration-300 border-0"
          >
            Book Appointment
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button 
            variant="outline"
            className="bg-transparent border-slate-700 text-slate-300 hover:bg-slate-900 hover:text-white px-8 py-6 text-lg rounded-full transition-all duration-300"
          >
            Our Services
          </Button>
        </div>
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />
    </section>
  );
}