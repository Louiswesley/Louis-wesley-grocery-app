import { Calendar } from "lucide-react";
import { brand } from "../utils/constants";

export function Booking() {
  return (
    <section id="booking" className="py-32 px-6 bg-slate-900 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-indigo-950/20 blur-3xl" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-indigo-500/20">
            <Calendar className="h-8 w-8 text-indigo-400" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-4 tracking-tight">
            Book Your Session
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Schedule your appointment with {brand.founder} and the team at {brand.name}
          </p>
        </div>

        <div className="bg-slate-950 rounded-3xl p-2 md:p-4 border border-slate-800 shadow-2xl">
          <div className="w-full h-[600px] md:h-[700px] rounded-2xl overflow-hidden bg-slate-900">
            <iframe
              src="https://calendly.com/"
              title="Book Appointment"
              className="w-full h-full border-0"
              frameBorder="0"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-8 mt-8 text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full" />
            <span className="text-sm">Instant Confirmation</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full" />
            <span className="text-sm">Reminders Included</span>
          </div>
        </div>
      </div>
    </section>
  );
}