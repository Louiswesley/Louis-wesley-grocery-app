import { MapPin, Mail, Phone, Heart, Star } from "lucide-react";
import { hours, contact, brand } from "../utils/constants";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 text-slate-400 py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-1">
            <h3 className="text-2xl font-bold text-slate-50 mb-4 tracking-tight">
              {brand.name}
            </h3>
            <p className="text-sm leading-relaxed mb-6">
              Founded by {brand.founder}. Your sanctuary for holistic beauty and wellness.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-slate-900 hover:bg-indigo-600 rounded-lg flex items-center justify-center transition-colors">
                <Heart className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-900 hover:bg-indigo-600 rounded-lg flex items-center justify-center transition-colors">
                <Star className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Hours */}
          <div>
            <h4 className="text-slate-50 font-semibold mb-6">Opening Hours</h4>
            <div className="space-y-3 text-sm">
              <p>{hours.weekdays}</p>
              <p>{hours.sunday}</p>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-slate-50 font-semibold mb-6">Contact Us</h4>
            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-indigo-500" />
                <span>{contact.address}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-indigo-500" />
                <span>{contact.phone}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-indigo-500" />
                <span>{contact.email}</span>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-slate-50 font-semibold mb-6">Stay Updated</h4>
            <p className="text-sm mb-4">Join {brand.founder}'s exclusive list for beauty tips and offers.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-sm text-slate-50 focus:outline-none focus:border-indigo-500 w-full"
              />
              <button className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm">
            © {new Date().getFullYear()} {brand.name}. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-indigo-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}