export const brand = {
  name: "Bud Again Beauty Spa",
  founder: "Amaka Oyoria",
  tagline: "Renew. Refresh. Radiate.",
};

export const services = [
  {
    id: 1,
    name: "Signature Facial",
    category: "Skincare",
    description: "Deep cleansing customized to your skin type with organic botanicals.",
    duration: "60 min",
    price: "$120",
  },
  {
    id: 2,
    name: "Deep Tissue Massage",
    category: "Massage",
    description: "Therapeutic pressure to release chronic muscle tension and stress.",
    duration: "90 min",
    price: "$150",
  },
  {
    id: 3,
    name: "Hydrating Body Wrap",
    category: "Body",
    description: "Full-body exfoliation followed by a nourishing shea butter wrap.",
    duration: "75 min",
    price: "$135",
  },
  {
    id: 4,
    name: "Anti-Aging Treatment",
    category: "Skincare",
    description: "Advanced peptide therapy to restore elasticity and youthful glow.",
    duration: "90 min",
    price: "$180",
  },
  {
    id: 5,
    name: "Hot Stone Therapy",
    category: "Massage",
    description: "Smooth heated stones placed on key points to melt away tension.",
    duration: "90 min",
    price: "$165",
  },
  {
    id: 6,
    name: "Bridal Glow Package",
    category: "Beauty",
    description: "Complete pre-event prep including facial, massage, and manicure.",
    duration: "3 hours",
    price: "$350",
  },
];

export const testimonials = [
  {
    id: 1,
    name: "Chioma A.",
    role: "Regular Client",
    quote: "Amaka has magic hands. The atmosphere at Bud Again is unmatched. I always leave feeling like a new person.",
  },
  {
    id: 2,
    name: "Ngozi E.",
    role: "Bride",
    quote: "The Bridal Glow Package was perfect for my wedding day. The team made me feel absolutely beautiful and relaxed.",
  },
  {
    id: 3,
    name: "Tunde B.",
    role: "Executive",
    quote: "The best spa experience I've had in the city. Professional, clean, and incredibly rejuvenating.",
  },
];

export const hours = {
  weekdays: "Mon–Sat: 9am–7pm",
  sunday: "Sun: 12pm–5pm",
};

export const contact = {
  address: "123 Wellness Avenue, Lekki Phase 1",
  phone: "+234 800 123 4567",
  email: "hello@budagainbeauty.com",
};